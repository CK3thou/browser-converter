<!-- Icon Placeholder Files

To complete the extension, you need to create actual icon images:

icon16.png (16x16 pixels) - Used in the extensions menu and toolbar
icon48.png (48x48 pixels) - Used in the extensions list
icon128.png (128x128 pixels) - Used in the Chrome Web Store

Recommended design:
- Use a simple, recognizable icon that represents "conversion"
- Suggested: Text with arrows, currency symbols, or clock with arrows
- Use colors: Purple gradient (#667eea to #764ba2) to match the extension theme
- Ensure clarity at small sizes

Tools to create icons:
- Adobe Photoshop
- GIMP (free)
- Figma (free)
- Canva (free)
- Online icon generators

Format: PNG with transparency for best results
-->
